package com.example.schedulemanagerapplication.utility;

import com.example.schedulemanagerapplication.model.User;

public class Helper {
    public static User user;
}
